-------------------------------------------------
-- Main Menu
-- Re-written by bc1 using Notepad++
-------------------------------------------------
do
include "MPGameDefaults"
local ResetMultiplayerOptions = ResetMultiplayerOptions

local ContextPtr = ContextPtr
local Controls = Controls
local Events = Events
local Modding = Modding
local Mouse = Mouse
local Network = Network
local PopupPriority = PopupPriority
local PreGame = PreGame
local Steam = Steam
local SystemUpdateUIType = SystemUpdateUIType
local UI = UI
local UIManager = UIManager

-------------------------------------------------
-- Event Handlers
ContextPtr:SetShowHideHandler( function( isHide, isInit )
	if not isHide and not isInit then
		-- This is a catch all to ensure that mods are not activated at this point in the UI.
		-- Also, since certain maps and settings will only be available in either the modding or multiplayer
		-- screen, we want to ensure that "safe" settings are loaded that can be used for either SP, MP or Mods.
		-- Activating the DLC (there doesn't have to be any) will make sure no mods are active and all the user's
		-- purchased content is available
		if not ContextPtr:IsHotLoad() then
			UIManager:SetUICursor( 1 )
			Modding.ActivateDLC()
			PreGame.LoadPreGameSettings()
			-- Send out an event to continue on, as the ActivateDLC may have swapped out the UI
			Events.SystemUpdateUI( SystemUpdateUIType.RestoreUI, "MainMenu" )
		end
		UIManager:SetUICursor( 0 )
	end
end)

Events.MultiplayerGameLaunched.Add( function()
	UIManager:DequeuePopup( ContextPtr )
end)

local function ReplayViewerRestoreUI( replayFile )
	Events.SystemUpdateUI( SystemUpdateUIType.RestoreUI, replayFile )
end
LuaEvents.ReplayViewer_LoadReplay.Add( ReplayViewerRestoreUI )

Events.SystemUpdateUI.Add( function( type, tag  )
	if type == SystemUpdateUIType.RestoreUI then
		if tag == "MainMenu" then
			-- Look for any cached invite
			UI:CheckForCommandLineInvitation()
			if Network.IsDedicatedServer() then
				ResetMultiplayerOptions()
				UIManager:QueuePopup( Controls.DedicatedServerScreen, PopupPriority.LobbyScreen )
			end
		elseif tag == "StagingRoom" then
			if not UIManager:GetVisibleNamedContext("StagingRoom") then
				UIManager:QueuePopup( Controls.StagingRoomScreen, PopupPriority.StagingScreen )
			end
		elseif tag == "ScenariosMenuReset" then
			local control = ContextPtr:LookUpControl( "SinglePlayerScreen/ScenariosScreen" )
			if control and control:IsHidden() then
				UIManager:QueuePopup( control, PopupPriority.GameSetupScreen )
			end
		elseif tag == "ModsBrowserReset" then
			local control = Controls.ModsBrowser
			if control and control:IsHidden() then
				UIManager:QueuePopup( control, PopupPriority.ModsBrowserScreen )
			end
		elseif tag == "ModsMenu" then
			local control = Modding.GetActivatedModEntryPoints"Custom"() and Controls.ModsCustom or Controls.ModdingGameSetupScreen
			if control and control:IsHidden() then
				UIManager:QueuePopup( control, PopupPriority.ModsMenuScreen )
			end
		elseif tag:sub(-10):lower() == "civ5replay" then
			local path = "Other/LoadReplayMenu/ReplayViewer"
			local control = ContextPtr:LookUpControl( path )
			if not control then
				ContextPtr:LookUpControl( "Other/LoadReplayMenu" ):DoDeferredLoad()
				control = ContextPtr:LookUpControl( path )
				if control and control:IsHidden() then
					UIManager:QueuePopup( control, PopupPriority.eUtmost )
					LuaEvents.ReplayViewer_LoadReplay.Remove( ReplayViewerRestoreUI )
					LuaEvents.ReplayViewer_LoadReplay( tag )
					LuaEvents.ReplayViewer_LoadReplay.Add( ReplayViewerRestoreUI )
				end
			end
		end
	end
end)

-------------------------------------------------
-- Script Body
Controls.VersionNumber:SetText( UI.GetVersionInfo():match"[%w%.]*" )
Steam.SetOverlayNotificationPosition( "bottom_left" )
Controls.TouchHelpButton:RegisterCallback( Mouse.eLClick, function() Controls.TouchControlsMenu:SetHide( false ) end )
Controls.TouchHelpButton:SetHide( not UI.IsTouchScreenEnabled() )

local function BuildEntry( text, popup, priority, first )
	if popup then
		local button = {}
		ContextPtr:BuildInstanceForControl( "MenuButton320", button, Controls.MainStack )
		button.Button:RegisterCallback( Mouse.eLClick, priority and function() UIManager:QueuePopup( popup, priority ) end or popup )
		button.Trim:SetHide( first )
		button.Button:LocalizeAndSetText( text )
	end
end
BuildEntry( "TXT_KEY_MENU_LOAD_GAME_BUTTON", ContextPtr:LookUpControl( "SinglePlayerScreen/LoadGameScreen" ), PopupPriority.LoadGameScreen, true )
BuildEntry( "TXT_KEY_MODDING_SINGLE_PLAYER", Controls.SinglePlayerScreen, PopupPriority.SinglePlayerScreen )
BuildEntry( "TXT_KEY_MULTIPLAYER", Controls.MultiplayerSelectScreen, PopupPriority.MultiplayerSelectScreen )
BuildEntry( "TXT_KEY_MODS", Controls.ModsBrowser, PopupPriority.ModsBrowserScreen )
BuildEntry( "TXT_KEY_LOAD_MENU_DLC", Controls.PremiumContentScreen, PopupPriority.OtherMenu )
BuildEntry( "TXT_KEY_OPTIONS", Controls.OptionsMenu_FrontEnd, PopupPriority.OptionsMenu )
BuildEntry( "TXT_KEY_OTHER", Controls.Other, PopupPriority.OtherMenu )
BuildEntry( "TXT_KEY_EXIT_BUTTON", Events.UserRequestClose.Call )
end