-------------------------------------------------
-- FrontEnd
-- Re-written by bc1 using Notepad++
-------------------------------------------------

local ContextPtr = ContextPtr
local Controls = Controls

local function SetAtlasLogo( texture )
	Controls.AtlasLogo:SetTextureAndResize( texture )
	local a, b = Controls.AtlasLogo:GetSizeVal()
	local x, y = UIManager:GetScreenSizeVal()
	local k = math.max( x/a, y/b )
	Controls.AtlasLogo:Resize( math.ceil(a*k), math.ceil(b*k) )
end

--local textures = { "wonderconceptpanamacanal.dds", "wonderconceptthreegeorgesdam.dds" }
local function SetRandomAtlasLogo()
	if ContextPtr:IsHidden() then
		Controls.AtlasLogo:UnloadTexture()
		Controls.Timer:Stop()
	else
		Controls.Timer:SetToBeginning()
		SetAtlasLogo( DB.Query("SELECT WonderSplashImage from Buildings Where WonderSplashImage IS NOT NULL ORDER By Random() LIMIT 1")().WonderSplashImage )
		return Controls.Timer:Play()
	end
end

Controls.EUI:ChangeParent( ContextPtr )
Controls.Timer:RegisterAnimCallback( SetRandomAtlasLogo )
Controls.Button:RegisterCallback( Mouse.eLClick, SetRandomAtlasLogo )

ContextPtr:SetShowHideHandler( function( isHide )
	if isHide then
		Controls.AtlasLogo:UnloadTexture()
		Controls.Civ5Logo:UnloadTexture()
		Controls.Timer:Stop()
	else
		SetAtlasLogo( "CivilzationVAtlas.dds" )
		Controls.Civ5Logo:SetTextureAndResize( "CivilzationV_Logo.dds" )
		UIManager:QueuePopup( Controls.MainMenu, PopupPriority.MainMenu )
	end
end)
