--==========================================================
-- Written by bc1 using Notepad++
--==========================================================

if not EUI then
	EUI = {}
	LuaEvents.GetEUI( EUI )
	EUI = EUI.EUI
	if not EUI then
		print "Loading EUI context"
		ContextPtr:LookUpControl(".."):LoadNewContext( "EUI_context" )
		EUI = {}
		LuaEvents.GetEUI( EUI )
		EUI = EUI.EUI
	end
end
if EUI then
--[[ for debug purposes only!
	print( "Found EUI context" )
	ContextPtr:SetShutdown( function()
		print( "Shutting down", Locale.ToNumber( collectgarbage("count") * 1024, "#,###,###,###" ) )
	end)
--]]
else
	print "Runtime error: could not find or load EUI context"
	EUI = {}
end
