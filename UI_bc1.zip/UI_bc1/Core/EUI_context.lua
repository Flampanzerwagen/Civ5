--==========================================================
-- EUI context hosts all lua code libraries, tooltips,
-- and game info cache; for use by all lua contexts
-- Written by bc1 using Notepad++
--==========================================================

local collectgarbage = collectgarbage
local pairs = pairs
local print = print
local setmetatable = setmetatable
--local tonumber = tonumber
local tostring = tostring
local insert = table.insert

local ContentManager = ContentManager
local ContentTypeGAMEPLAY = ContentType.GAMEPLAY
local ContextPtr = ContextPtr
local Game = Game
local Locale = Locale
local Modding = Modding

local function LuaMemoryUsed()
	return "Lua memory in use: ".. Locale.ToNumber( collectgarbage("count") * 1024, "#,###,###,###" )
end

print( "Loading EUI context", LuaMemoryUsed() )

local UserData = Modding.OpenUserData( "Enhanced User Interface Options", 2 )
local GetUserDataValue = UserData.GetValue

local EUIoptionsCache = setmetatable( {}, { __index = function( t, k ) local v = GetUserDataValue( k ) or 1 t[k] = v return v end } )
local EUIoptions = setmetatable( {}, { __index = EUIoptionsCache } )

EUI = {
	Options = EUIoptions,
}

--==========================================================
-- Listener supplies pointer to EUI function and data table
-- Caller needs to pass a table: its EUI field will be set
LuaEvents.GetEUI.Add( function(t) t.EUI = EUI end )

--==========================================================
-- Sometime after game init is complete, LoadScreen context gets destroyed
-- Its children get destroyed too: need to find new parent fast!
Events.SequenceGameInitComplete.Add( function()
--	ContextPtr:ChangeParent( LookUpControl( "/LeaderHeadRoot" ) ) -- LookUpControl( "/InGame" ) ) --
--	print( "Moved to /LeaderHeadRoot.", LuaMemoryUsed(), "\n", (">"):rep(100) )
	print( "SequenceGameInitComplete", LuaMemoryUsed() )
end)

ContextPtr:SetShutdown( function()
	print( "Shutting down..." )
	local SetUserDataValue = UserData.SetValue
	for k, v in pairs( EUIoptions ) do
		if v ~= EUIoptionsCache[k] then
			SetUserDataValue( k, v )
		end
	end
	if MapModData then
		MapModData.UI_bc1 = nil	-- Consistency with older EUI versions: does anyone use this ?
		print( "Ingame shutdown complete.", LuaMemoryUsed(), "\n", ("="):rep(100), "\n\n\n" )
	else
		print( "Pregame shutdown complete.", LuaMemoryUsed(), "\n", ("="):rep(100), "\n\n\n" )
	end
end)

--==========================================================
-- Print game DLC and MOD configuration for debug
local function PrintGameConfiguration( flag )
	local t= { flag==true and LuaMemoryUsed() or "MOD/DLC activation.\t"..LuaMemoryUsed(), ("_"):rep(100) }
	for _, v in pairs( ContentManager.GetAllPackageIDs() ) do
		insert( t, (ContentManager.IsActive(v, ContentTypeGAMEPLAY) and "Active DLC:  \t" or "Disabled DLC:\t")..tostring(v).."\t"..Locale.Lookup(ContentManager.GetPackageDescription(v)) )
	end
	for _, v in pairs( Modding.GetActivatedMods() ) do
		insert( t, "Active MOD:  \t".. tostring(v.ID) .. "\t" .. tostring( Modding.GetModProperty(v.ID, v.Version, "Name") ) .. " v"..tostring(v.Version) )
		if v.ID == "34fb6c19-10dd-4b65-b143-fd00b2c0826f" then
			EUI.deluxe_scenario = true
		end
	end
	insert( t, ("¯"):rep(100) )
	print( table.concat(t,"\n\t") )
end
--Events.AfterModsDeactivate.Add( PrintGameConfiguration )
Events.AfterModsActivate.Add( PrintGameConfiguration )
PrintGameConfiguration( true )

if Game then
	MapModData.UI_bc1 = EUI	-- Consistency with older EUI versions: does anyone use this ?
	include "EUI_tooltip_server"
	print( "Ingame start.", LuaMemoryUsed() )
else
	print( "Pregame start.", LuaMemoryUsed() )
end

collectgarbage()
